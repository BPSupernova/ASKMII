#include "Object.h"
#include "WorldManager.h"

df::Object::Object() {
	static int unique_id = 0; // Variable id is obtained from
	o_id = unique_id; 
	unique_id += 1; // Increment for next object

	o_type = "Object";

	df::Vector2D intitial_vec;
	o_position = intitial_vec; // Default position when initialized in game world (0,0)
	
	WM.getInstance().insertObjectToWorld(this); // Add self into the game world  
}

df::Object::~Object() {
	WM.getInstance().removeObjectFromWorld(this); // Destroy Object and delete from WorlManager
}

int df::Object::eventHandler(const Event* p_e)
{
	return 0;
}

void df::Object::setID(int new_o_id) {
	o_id = new_o_id;
}

int df::Object::getID() const {
	return o_id;
}

void df::Object::setType(std::string new_type) {
	o_type = new_type;
}

std::string df::Object::getType() const {
	return o_type;
}

void df::Object::setPosition(Vector2D new_pos) {
	o_position = new_pos;
}

df::Vector2D df::Object::getPosition() const {
	return o_position;
}
