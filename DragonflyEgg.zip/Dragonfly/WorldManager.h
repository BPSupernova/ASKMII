#ifndef WORLD_MANAGER_H
#define WORLD_MANAGER_H

#include "Manager.h"
#include "ObjectList.h"
#include <stdio.h>
#include <map>

#define WM df::WorldManager::getInstance()

namespace df {
	class WorldManager : public Manager {
	private:
		WorldManager(); // Singleton
		WorldManager(WorldManager const&); // Doesn't allow copying
		void operator = (WorldManager const&); // Doesn't allow assignment

		df::ObjectList object_updates; // All game Objects to update
		df::ObjectList deletions; // All game Objects to delete

	public:
		static WorldManager &getInstance(); // Get WorldManager instance
		int startUp(); // Initialize everything in game world; Return 0 upon success
		void shutDown(); // Shutdown the game world and delete all game world Objects

		int insertObjectToWorld(Object* p_o); // Inserts Object into game world; 0 upon success, -1 otherwise
		int removeObjectFromWorld(Object* p_o); // Deletes Object from game world; 0 upon success, -1 otherwise

		df::ObjectList getAllObjects() const; // Returns a list of all game Objects in the world
		df::ObjectList getObjectsOfType(std::string type) const; // Returns a list of all game Objects in the world of the parameter type

		void UpdateWorld(); // Continually updates the game world and marks Objects for deletion
		int MarkForDelete(Object *p_o); // Indicates an Object to be deleted at the end of the current game loop; 0 upon success, -1 otherwise
	};
}

#endif

