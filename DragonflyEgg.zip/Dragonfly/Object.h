#ifndef OBJECT_H
#define OBJECT_H

#include <string>
#include "Vector2D.h"
#include "Event.h"

namespace df {
	class Object {
	private:
		int o_id; // Unique game engine defined identifier
		std::string o_type; // Game programmer defined type
		df::Vector2D o_position; // Object's position in game world

	public:
		Object(); // Constructs & adds object to game world via WorldManager
		virtual ~Object(); // Destroys object, which removes it from the game world via WorldManager

		virtual int eventHandler(const Event* p_e);

		void setID(int new_o_id); // set the object's unique id
		int getID() const; // get the object's unique id

		void setType(std::string new_type); // Set the type identifier of object
		std::string getType() const; // Get the type identifier of object

		void setPosition(Vector2D new_pos); // Set position of object
		df::Vector2D getPosition() const; // Get position of object
	};
}
#endif