#include <stdio.h>
#include <stdarg.h>
#include <map> 
#include <iostream>
#include <fstream>
#include "GameManager.h"
#include "LogManager.h"
#include "WorldManager.h"
#include "Clock.h"
#include "ObjectList.h"
#include "ObjectListIterator.h"
#include "Event.h"
#include "EventStep.h"
#include "TestObject.h"

int main() {
	df::Clock test_clock;
	/* Test delta */
	
	long int delta_time = test_clock.delta();
	printf("Delta Time: %ld\n", delta_time);
	
/********************************************************************************************************************************************************/
	
	df::Vector2D* test_vector = new df::Vector2D(3,4);
	df::Vector2D test_vector_2;
	
	/* Test Vector2D functions */
	std::cout << "Test Vector 1 has an x of " << test_vector->getX() << ", a y of " << test_vector->getY() << ", and a magnitude of " << test_vector->getMagnitude() << std::endl;
	// Should return 3 (for x), 4 (for y), and 5 (for magnitude)

	std::cout << "Test Vector 2 has an x of " << test_vector_2.getX() << ", a y of " << test_vector_2.getY() << std::endl;
	// Check to see if Vector2D is auto set to position (0,0)

	/* Scale Vector */
	test_vector->scale(2);
	std::cout << "Test Vector 1 now has an x of " << test_vector->getX() << ", a y of " << test_vector->getY() << std::endl; 
	// Should return 6 (for x) and 8 (for y)

	/* Normalize Vector */
	test_vector->normalize();
	std::cout << "Test Vector 1 now has a magnitude of " << test_vector->getMagnitude() << std::endl;
	// Should return 1 (for magnitude)

	/* Check + Operator */
	test_vector->setXY(3, 4);
	test_vector_2.setXY(1, 2);
	df::Vector2D sum_vector = test_vector_2.operator+(*test_vector);
	std::cout << "The sum vector has an x of " << sum_vector.getX() << ", a y of " << sum_vector.getY() << std::endl; 
	// Should return 4 (for x) and 6 (for y)

	/* End of Vector2D tests */

/********************************************************************************************************************************************************/
	/* Test LogManager startUp() */
	
	int start_state = LM.startUp(); // Check for dragonfly.log in file explorer
	std::cout << "Start state (for LogManager) is: " << start_state << std::endl; // Good if 0 is printed; not good if -7 is printed
	
	/* Test writeLog */
	
	LM.writeLog("This is my age: %d\n", 19); // Check dragonfly.log
	LM.writeLog("Multiple values: %s, %d, %f\n", "Hello", 23, 14.5); // Test writeLog with multiple arguments and types
	
		/* Test setFlush */
//	LM.getInstance().setFlush(false); // Checks to see if can set the flush in first place; commented this test out to ensure that frush is auto set to true
	LM.writeLog("Multiple values: %s, %d, %f\n", "Hello", 23, 14.5);
				
	/* End of setFlush test */

	/* End of writeLog test */
/*********************************************************************************************************************************************************/
	
	/* Test split */
	// Sleep(2); // Sleep for 2 seconds if needed
	long int split_time = test_clock.split();
	printf("Split Time: %ld\n", split_time);  
	
/*********************************************************************************************************************************************************/
	/* Test LogManager shutDown() function */
	
	LM.shutDown();
	bool lm_shutdown_success = LM.isStarted();
	std::cout << "Close state (for LogManager) is: " << lm_shutdown_success << std::endl; // Good if 0 is printed (false); not good if 1 is printed
	
/*********************************************************************************************************************************************************/
	/* Test GameManager startUp() function */
	
	GM.startUp();
	int gm_start_state = GM.isStarted();
	int lm_start_state_2 = LM.isStarted(); // Make sure LogManager is started w/GameManager
	int wm_start_state = WM.isStarted(); // Make sure WorldManager is started w/GameManager
	std::cout << "Start state (for GameManager) is: " << gm_start_state << std::endl; // Good if 1 is printed; not good if 0 is printed
	std::cout << "Start state (for LogManager; from GameManager) is: " << lm_start_state_2 << std::endl; // Good if 1 is printed; not good if 0 is printed
	std::cout << "Start state (for WorldManager; from GameManager) is: " << wm_start_state << std::endl; // Good if 1 is printed; not good if 0 is printed

/*********************************************************************************************************************************************************/
	/* Test Object functionalties */
	
	df::Object test_object; 
	std::cout << "Test Object starts with id " << test_object.getID() << ", type " << test_object.getType() << ", and position " << test_object.getPosition().getMagnitude() << std::endl;
	// Should return 0 (for id), "Object" (for type), and 0 (for the length of the position Vector; thus confirming the coordinates [0,0])

/*********************************************************************************************************************************************************/
	/* Test ObjectList functionality */

	df::Object *test_object_2 = new df::Object();
	df::Object* test_object_3 = new df::Object();
	df::ObjectList test_objlist;
	std::cout << "This object list starts with a count of " << test_objlist.getCount() << std::endl; // Should be initialized to 0
	std::cout << "Empty Check: " << test_objlist.isEmpty() << std::endl; // Should return 1 (as in true)
	std::cout << "Full Check: " << test_objlist.isFull() << std::endl; // Should return 0 (as in false)

	/* Test insert & remove */

	std::cout << "Add 1: " << test_objlist.insert(test_object_2) << std::endl; // 0 for success; -1 fail 
	std::cout << "Add 2: " << test_objlist.insert(test_object_3) << std::endl; // 0 for success; -1 fail
	std::cout << "Remove 1: " << test_objlist.remove(test_object_3) << std::endl; // 0 for success; -1 for fail
	std::cout << "Also # of objects in list: " << test_objlist.getCount() << std::endl; // Should return 1 (ADd 2, remove 1)
	

		/* Test ObjectListIterator functionality */
	
	df::ObjectListIterator test_list_iterator(&test_objlist);
	for (test_list_iterator.first(); !test_list_iterator.atEnd(); test_list_iterator.next()) {
		df::Object* currObjPointer = test_list_iterator.currentObject();
		std::cout << "Iterator is on Object " << currObjPointer->getID() << std::endl; // Make sure iterator is currently iterating (Should return incrementing values)
	} 
		/* End of ObjectListIterator tests */

	test_objlist.clear();
	std::cout << "This object list ends off with " << test_objlist.getCount() << std::endl; // Should return 0 upon using clear()

/*********************************************************************************************************************************************************/
	/* Test GameManager functions */
	
	int frame_time = GM.getFrameTime(); // Should return 33
	int step_count = GM.getStepCount(); // Should return zero rn
	bool test_game_over_1 = GM.getGameOver(); // Should return false; initialized in constructor
	// GM.run(); // testing Sleep() functionality 
	GM.setGameOver(true);
	bool test_game_over_2 = GM.getGameOver(); // Should return true

	std::cout << "GameManager stats: Frame Time (" << frame_time << "); Step Count (" << step_count << "); Game Over 1 (" << test_game_over_1 << "); Game Over 2 (" << test_game_over_2 << ")" << std::endl;
	// The above prints all the variables defined in this section; TIMING IS TESTED IN GAMEMANAGER ITSELF
	
/*********************************************************************************************************************************************************/
	/* Event testing */
	df::Event cool_event; // Type should be "df::undefined"
	df::EventStep cool_step_event; // Type should be "Step"
	std::cout << "cool_event is type " << cool_event.getType() << " and cool_step_event is type " << cool_step_event.getType() << std::endl;  

	df::TestObject event_handler_dummy;
	event_handler_dummy.eventHandler(&cool_event); // Should return -2
	event_handler_dummy.eventHandler(&cool_step_event); // Should return 10

/*********************************************************************************************************************************************************/
	/* WorldManager tests */
	test_object_3->setType("Friendly"); 

	// Test insertObjectToWorld
	//WM.getInstance().insertObjectToWorld(&test_object);
	//WM.getInstance().insertObjectToWorld(test_object_2);
	//std::cout << "Insert Into World Success: " << WM.getInstance().insertObjectToWorld(test_object_3) << std::endl; // Should return 0
	
	// Test removeObjectFromWorld
	//std::cout << "Remove From World Success: " << WM.getInstance().removeObjectFromWorld(test_object_2) << std::endl; // Should return 0

	// Test getAllObjects & objectsOfType
	df::ObjectList objects_in_world =  WM.getInstance().getAllObjects();
	df::ObjectList friendly_objs_in_world = WM.getInstance().getObjectsOfType("Friendly");
	std::cout << "This list (objects_in_world) has " << objects_in_world.getCount() << " objects in it" << std::endl; // Should return 2 (3 inserts, 1 remove)
	std::cout << "This list (friendly_objs_in_world) has " << friendly_objs_in_world.getCount() << " objects in it" << std::endl; // Should return 1

	df::ObjectListIterator world_obj_it(&objects_in_world);
	df::ObjectListIterator fr_world_obj_it(&friendly_objs_in_world);

	for (world_obj_it.first(); !world_obj_it.atEnd(); world_obj_it.next()) {
		std::cout << "objects_in_world -> current item: " << world_obj_it.currentObject()->getID() << std::endl;
	}

	for (fr_world_obj_it.first(); !fr_world_obj_it.atEnd(); fr_world_obj_it.next()) {
		std::cout << "friendly_objs_in_world -> current item: " << fr_world_obj_it.currentObject()->getID() << std::endl;
	}

	delete(test_object_2);
	
	WM.getInstance().MarkForDelete(&test_object);
	// WM.getInstance().MarkForDelete(test_object_2); -> uncomment if deleting line 186
	WM.getInstance().MarkForDelete(test_object_3);
	WM.getInstance().MarkForDelete(&event_handler_dummy);
	// WM.UpdateWorld(); // -> done in GameManager every game loop successfully
	objects_in_world = WM.getInstance().getAllObjects(); // Use for extra testing if necessary

/*********************************************************************************************************************************************************/
	/* Test GameManager shutDown() function */
	
	GM.shutDown();
	printf("Done\n");
	int gm_shutdown_success = GM.isStarted();
	int lm_shutdown_success_2 = LM.isStarted();
	int wm_shutdown_success = WM.isStarted();
	std::cout << "Close state (for GameManager) is: " << gm_shutdown_success << std::endl; // Good if 0 is printed (false); not good if 1 is printed
	std::cout << "Close state (for LogManager; from GameManager) is: " << lm_shutdown_success_2 << std::endl; // Good if 0 is printed; not good if 1 is printed
	std::cout << "Close state (for WorldManager; from GameManager) is: " << wm_shutdown_success << std::endl; // Good if 0 is printed; not good if 1 is printed
} // Corrupted error here for ObjectList somehow
