#include "TestObject.h"
#include "EventStep.h" 

df::TestObject::TestObject() {

}

df::TestObject::~TestObject() {

}

int df::TestObject::eventHandler(const df::Event* p_e) {
	if (p_e->getType() == df::STEP_EVENT) {
		return 10;
	}

	if (p_e->getType() == df::UNDEFINED_EVENT) {
		return -2;
	}

	return 0;
}
