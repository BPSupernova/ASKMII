#include "WorldManager.h"

df::WorldManager::WorldManager() {
	object_updates = ObjectList();
	deletions = ObjectList();
}

df::WorldManager &df::WorldManager::getInstance() { 
	static WorldManager world_manager;
	return world_manager;
}

int df::WorldManager::startUp()
{
	df::Manager::startUp();
	return 0;
}

void df::WorldManager::shutDown() {
	ObjectList ol = object_updates; // Copy list
	ObjectListIterator li(&ol);
	
	for (li.first(); !li.atEnd(); li.next()) {
		MarkForDelete(li.currentObject());
	}
	df::Manager::shutDown();
}

int df::WorldManager::insertObjectToWorld(Object* p_o) {
	object_updates.insert(p_o);
	return 0;
}

int df::WorldManager::removeObjectFromWorld(Object* p_o) {
	object_updates.remove(p_o);
	return 0;
}

df::ObjectList df::WorldManager::getAllObjects() const {
	return object_updates;
}

df::ObjectList df::WorldManager::getObjectsOfType(std::string type) const {
	ObjectList list;
	ObjectListIterator list_iterator(&object_updates);

	for (list_iterator.first(); !list_iterator.atEnd(); list_iterator.next()) {
		if (list_iterator.currentObject()->getType() == type) {
			list.insert(list_iterator.currentObject());
		}
	}
	return list;
}

void df::WorldManager::UpdateWorld() {
	ObjectListIterator deleter_iterator(&deletions);
	
	while (!deleter_iterator.atEnd()) {
		delete(deleter_iterator.currentObject());
		deleter_iterator.next();
	}
	deletions.clear();
}

int df::WorldManager::MarkForDelete(Object* p_o) {
	ObjectListIterator deletor_iterator(&deletions);

	while (!deletor_iterator.atEnd()) {
		if (deletor_iterator.currentObject() == p_o) {
			return 0;
		}
		deletor_iterator.next();
	}
	deletions.insert(p_o);
	return -1;
}
