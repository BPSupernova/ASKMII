#ifndef TEST_OBJECT
#define TEST_OBJECT

#include "Object.h"

namespace df {

	class TestObject : public Object {
	public:
		TestObject();
		~TestObject();
		int eventHandler(const df::Event* p_e) override; // Returns an integer code based on the Event type; -2 for base Event; 10 for Step
	};
}

#endif