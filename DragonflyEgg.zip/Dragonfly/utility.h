#include <string>

namespace df {
	class utility {
	public:
		char* getTimeString();
	};
}
