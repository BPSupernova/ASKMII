#include "Manager.h"

df::Manager :: Manager() {

}

df::Manager :: ~Manager() {

}

std::string df::Manager::getType() const
{
	return df::Manager::m_type;
}

int df::Manager::startUp()
{
	df::Manager::manager_is_started = true;
	if (df::Manager::manager_is_started)
		return 0;
	else
		return -7;
}

void df::Manager::shutDown()
{
	df::Manager::manager_is_started = false;
}

bool df::Manager::isStarted() const
{
	bool started_fine = true;
	if (df::Manager::manager_is_started != true) { started_fine = false; }
	return started_fine;
}

void df::Manager::setType(std::string type)
{
	type = "Manager";
}

