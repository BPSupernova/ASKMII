#include "GameManager.h"
#include "LogManager.h"
#include "WorldManager.h"
#include <Windows.h>
#include "EventStep.h"
#include "Clock.h"
#include <stdio.h>
#include <iostream>

df::GameManager::GameManager() {
	game_over = false;
	m_step_count = 0;
	frame_time = 33;
}

df::GameManager &df::GameManager::getInstance() {
	static GameManager game_manager;
	return game_manager;
}

int df::GameManager::startUp() {
	LM.startUp();
	WM.startUp();
	df::Manager::startUp();
	timeBeginPeriod(1);
	return 0;
}

void df::GameManager::shutDown() {
	WM.shutDown();
	LM.shutDown();
	df::Manager::shutDown(); 
	timeEndPeriod(1);
	game_over = true;
}

void df::GameManager::run() {
	df::Clock clock;
	
	while (!game_over) {
		long int b = clock.delta();
		/* printf("%ld\n", b); FOR TESTING ONLY */

		//Get input
		WM.getInstance().UpdateWorld();
		//Draw current scene to back buffer
		//Swap back buffer to current buffer

		ObjectList all_game_objects = WM.getInstance().getAllObjects(); // All objects active in game world
		EventStep s(getStepCount());
		ObjectListIterator all_gobj_iterator(&all_game_objects);
		while (!all_gobj_iterator.atEnd()) { // Send a EventStep to all game Objects
			all_gobj_iterator.currentObject()->eventHandler(&s);
			all_gobj_iterator.next();
		}

		long int loop_time = clock.split();
		/* printf("%ld\n", loop_time); FOR TESTING ONLY */
		if (33 - loop_time < 0) { continue; }
		else { Sleep(33 - loop_time); }
	}
}

void df::GameManager::setGameOver(bool new_game_over) {
	game_over = new_game_over;
}

bool df::GameManager::getGameOver() const {
	return game_over;
}

int df::GameManager::getFrameTime() const {
	return frame_time;
}

int df::GameManager::getStepCount() const {
	return m_step_count;
}
