Name: Benjamin Perry
WPI Username: bjperry
Platform: Windows (11)

All of my header and source files were stored in the following folder/directory: C:\Users\Ben\source\repos\dragonfly\Dragonfly

The Dragonfly.sln solution file was stored in C:\Users\Ben\source\repos\dragonfly

The executable Dragonfly was located in C:\Users\Ben\source\repos\dragonfly\x64\Debug

ALL of my test code and tests to assess the functionality of the game engine are located in Game.cpp. I made the comments very informative and organized. If you have any questions regarding the tests, please reach out to me. The test code almost entirely prints to the terminal upon running the build in Visual Studio. The only exception lies in the LogManager specific tests, which are located in their own section in Game.cpp and have comments that detail what should appear in the log file when running the test code yourself.